document.addEventListener("DOMContentLoaded", function() {
    let button = document.querySelector(".button");
    let input = document.querySelector("input");

    button.addEventListener("click", function() {
        let godName = input.value.trim();
        
        if (godName === "") {
            alert("कृपया भगवान का नाम लिखें!");
        } else {
            alert("🔓 आपका '" + godName + "' लॉकर खुल गया!");
        }
    });
});
